
extends Control

@export_file("*.tscn") var cena_principal: String = "res://Cenas/principal.tscn"

@onready var video: VideoStreamPlayer = $VideoStreamPlayer

var _finalizada: bool = false


func _ready() -> void:
	video.expand = true
	video.loop = false

	if not video.finished.is_connected(_on_video_finished):
		video.finished.connect(_on_video_finished)

	if video.stream == null:
		push_error("Atribua o vídeo à propriedade Stream do VideoStreamPlayer.")
		return

	video.play()


func _on_video_finished() -> void:
	if _finalizada:
		return

	_finalizada = true

	await _ir_para_jogo()


func _ir_para_jogo() -> void:
	await Jogo.trocar_cena(cena_principal, false)
